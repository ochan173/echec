package echec;

public class Piece {
    public enum Couleur {Blanc, Noir}
    public enum TypePiece {Pion, Tour, Fou, Cavalier, Reine, Roi}

    private Couleur m_couleur;
    private char m_representation;
    private TypePiece m_type;

    public static Piece obtenirPiece(Couleur p_couleur, TypePiece p_type) {
        return new Piece(p_couleur, p_type);
    }

    private Piece(Couleur p_couleur, TypePiece p_type) {
        m_couleur = p_couleur;
        m_type = p_type;

        switch (p_type) {
            case Pion: m_representation = 'p';
                break;
            case Tour: m_representation = 't';
                break;
            case Fou: m_representation = 'f';
                break;
            case Cavalier: m_representation = 'c';
                break;
            case Reine: m_representation = 'd';
                break;
            case Roi: m_representation = 'r';
                break;
        }
        if(p_couleur == Couleur.Noir) {
            m_representation = Character.toUpperCase(m_representation);
        }
    }

    public static Piece[] genererPieces(Couleur p_couleur) {
        Piece[] retour;
        if(p_couleur == Couleur.Blanc) {
            retour = new Piece[]{new Piece(p_couleur, TypePiece.Tour),
                    new Piece(p_couleur, TypePiece.Cavalier),
                    new Piece(p_couleur, TypePiece.Fou),
                    new Piece(p_couleur, TypePiece.Reine),
                    new Piece(p_couleur, TypePiece.Roi),
                    new Piece(p_couleur, TypePiece.Fou),
                    new Piece(p_couleur, TypePiece.Cavalier),
                    new Piece(p_couleur, TypePiece.Tour)};
        }
        else {
            retour = new Piece[]{new Piece(p_couleur, TypePiece.Tour),
                    new Piece(p_couleur, TypePiece.Cavalier),
                    new Piece(p_couleur, TypePiece.Fou),
                    new Piece(p_couleur, TypePiece.Reine),
                    new Piece(p_couleur, TypePiece.Roi),
                    new Piece(p_couleur, TypePiece.Fou),
                    new Piece(p_couleur, TypePiece.Cavalier),
                    new Piece(p_couleur, TypePiece.Tour)};
        }
        return retour;
    }

    public static Piece[] genererPions(Couleur p_couleur) {
        Piece[] retour = new Piece[8];
        for (int i = 0; i < 8; i++) {
            retour[i] = new Piece(p_couleur, TypePiece.Pion);
        }
        return retour;
    }

    public char getRepresentation() {
        return m_representation;
    }

    public Couleur getCouleur() {
        return m_couleur;
    }

    public boolean estBlanc() {
        return m_couleur == Couleur.Blanc;
    }
    public boolean estNoir() {
        return m_couleur == Couleur.Noir;
    }
}
