package echec;

import java.util.List;

public class Piece {
    private String m_couleur;
    private char m_nom;

    private Piece(String p_couleur, char p_nom) {
        m_couleur = p_couleur;
        m_nom = p_nom;
    }

    public static Piece[] genererPieces(String p_couleur) {
        Piece[] retour;
        if(p_couleur == "blanc") {
            retour = new Piece[]{new Piece(p_couleur, 't'),
                    new Piece(p_couleur, 'c'),
                    new Piece(p_couleur, 'f'),
                    new Piece(p_couleur, 'd'),
                    new Piece(p_couleur, 'r'),
                    new Piece(p_couleur, 'f'),
                    new Piece(p_couleur, 'c'),
                    new Piece(p_couleur, 't')};
        }
        else {
            retour = new Piece[]{new Piece(p_couleur, 'T'),
                    new Piece(p_couleur, 'C'),
                    new Piece(p_couleur, 'F'),
                    new Piece(p_couleur, 'D'),
                    new Piece(p_couleur, 'R'),
                    new Piece(p_couleur, 'F'),
                    new Piece(p_couleur, 'C'),
                    new Piece(p_couleur, 'T')};
        }
        return retour;
    }

    public static Piece[] genererPions(String p_couleur) {
        Piece[] retour = new Piece[8];
        for (int i = 0; i < 8; i++) {
            if (p_couleur == "noir") {
                retour[i] = new Piece(p_couleur, 'P');
            }
            else {
                retour[i] = new Piece(p_couleur, 'p');
            }
        }
        return retour;
    }

    public char getNom() {
        return m_nom;
    }
}
