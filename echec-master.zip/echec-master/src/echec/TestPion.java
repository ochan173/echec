package echec;

import junit.framework.TestCase;

/**
 * Classe de tests pour un pion
 *
 * @author Olivier Chan
 * @author David Goulet
 */
public class TestPion extends TestCase {
    /**
     * Méthode qui teste la création d'un pion
     */
    public void testCreer() {
        Piece pionNoir = Piece.obtenirPiece(Piece.Couleur.Noir, Piece.TypePiece.Pion);
        Piece pionBlanc = Piece.obtenirPiece(Piece.Couleur.Blanc, Piece.TypePiece.Pion);

        assertEquals(Piece.Couleur.Blanc, pionBlanc.getCouleur());
        assertEquals(Piece.Couleur.Noir, pionNoir.getCouleur());

        assertEquals(true, pionBlanc.estBlanc());
        assertEquals(true, pionNoir.estNoir());

        assertEquals('p', pionBlanc.getRepresentation());
        assertEquals('P', pionNoir.getRepresentation());
    }
}
